from webgui.index import run


def main():
    print("Starting!")
    run()
